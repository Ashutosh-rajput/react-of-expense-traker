// import { myAxios } from "./helper";

// const signUp=(user)=>{
//     return myAxios
//        .post('/user/create-user')
//        .then((response)=>response.json());
// }; 